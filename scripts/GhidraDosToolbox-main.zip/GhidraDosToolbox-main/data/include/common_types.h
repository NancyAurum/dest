/*
 *  Common types used in the include files
 */

/*
 * Used to denote a Segment part of an address
 */
#ifndef SEGMENT
typedef word	SEGMENT;
#endif

